import logo from '../logo.svg';
import './App.css';
import Header from "./header"

function App() {
  return (
    <div className="App">
       <Header subtitle='Buy a house from us, and get 20% cash back.No rush! ' anotherTitle='I am the twin'/>
    </div>
  );
}

export default App;
